 'use client'
import { getUserToken } from "@/app/Helpers/getUserToken/getUserToken";
import { cartResponse } from "@/interfaces/cart";
import { decode } from "next-auth/jwt";
import { useSession } from "next-auth/react";
import { cookies } from "next/headers";
import { createContext, ReactNode, useEffect, useState } from "react";

export const CartContext = createContext<{
    cartData : cartResponse|null ,
    setCartData : (value :cartResponse|null)=> void ,
    isLoading : boolean ,
    setIsLoading : (value : boolean)=>void ,
    getCart : ()=>void ,
    
}>({
cartData : null ,
setCartData : ()=>{} ,
isLoading : false ,
setIsLoading : ()=>{} ,
getCart()  { },


});

export default function CartContextProvider({children}:{children : ReactNode}){
    const [cartData, setCartData] = useState<cartResponse|null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const session = useSession()
    

 async function getCart() {
     
    const x = (await cookies()).get('next-auth.session-token')?.value;
    const accessToken = await decode({token : x , secret : process.env.AUTH_SECRET!})
     const response = await fetch('https://ecommerce.routemisr.com/api/v1/cart' , {
            method : 'GET',
            headers : {
                token :accessToken +''
            }
        }) ;
    const data : cartResponse = await response.json()  ;
    setCartData(data) ;
    if (cartData?.data.cartOwner) {
        localStorage.setItem('userId' , cartData?.data.cartOwner)
        
        
    }
    setIsLoading(false);
    
        
    
}
    
    useEffect(()=>{
      
         getCart();
       
        
       
    },[])

return  <CartContext.Provider value={{cartData , setCartData , isLoading , setIsLoading , getCart   }}>
    {children}
</CartContext.Provider>
}