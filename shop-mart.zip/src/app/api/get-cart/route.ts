import { getUserToken } from "@/app/Helpers/getUserToken/getUserToken";
import { cartResponse } from "@/interfaces/cart";
import { decode } from "next-auth/jwt";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function GET() {
    // const token = await getUserToken()
    const x = (await cookies()).get('next-auth.session-token')?.value;
    const accessToken = await decode({token : x , secret : process.env.AUTH_SECRET!})
     const response = await fetch('https://ecommerce.routemisr.com/api/v1/cart' , {
            method : 'GET',
            headers : {
                token : accessToken+''
            }
        }) ;
        const data : cartResponse = await response.json()  ;

        return NextResponse.json(data)
}